const axios=require('axios');
const response = axios.get('http://localhost:3000/Cityname/Services');
const filteredData = response.data.map(item => ({
            Cityname: item.Cityname,
            Services: item.Services}));
            console.log(filteredData);
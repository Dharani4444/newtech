const axios=require("axios");
axios.get("http://localhost:3000/items/1",{"itemname":"black coffee"}).then((e) => console.log(e.data));